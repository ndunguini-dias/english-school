function exportarCertificados(){
 const cert = localStorage.getItem("certNumero");
 alert("Último certificado: " + cert);
}

function limparSistema(){
 if(confirm("Deseja limpar tudo?")){
  localStorage.clear();
  alert("Sistema limpo");
 }
}

