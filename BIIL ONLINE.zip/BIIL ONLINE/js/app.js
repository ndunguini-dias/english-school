/* =========================
   SLIDESHOW — página inicial
========================= */
document.addEventListener("DOMContentLoaded", ()=>{

  const slides = document.querySelectorAll(".hero-img");

  if(slides.length > 0){
    let current = 0;

    setInterval(()=>{
      slides.forEach((s,i)=>{
        s.style.opacity = (i === current ? 1 : 0);
      });
      current = (current + 1) % slides.length;
    }, 5000);
  }

});


/* =========================
   LOGIN / CADASTRO
========================= */

function mostrarCadastro(){
  const l = document.getElementById('loginBox');
  const c = document.getElementById('cadastroBox');
  if(l && c){
    l.classList.add('hidden');
    c.classList.remove('hidden');
  }
}

function mostrarLogin(){
  const l = document.getElementById('loginBox');
  const c = document.getElementById('cadastroBox');
  if(l && c){
    c.classList.add('hidden');
    l.classList.remove('hidden');
  }
}

function saveUser(u){
  localStorage.setItem("user", JSON.stringify(u));
}

function getUser(){
  return JSON.parse(localStorage.getItem("user"));
}

function fazerCadastro(){

  const payload = {
    nome: nome.value.trim(),
    apelido: apelido.value.trim(),
    nascimento: nascimento.value,
    telefone: telefone.value.trim(),
    endereco: endereco.value.trim(),
    senha: senhaCadastro.value
  };

  if(Object.values(payload).some(v => !v)){
    cadMsg.innerHTML = "Preencha todos os campos!";
    return;
  }

  saveUser(payload);
  cadMsg.innerHTML = "Conta criada com sucesso!";
  setTimeout(mostrarLogin, 1200);
}

function fazerLogin(){

  const user = getUser();
  if(!user){
    loginMsg.innerHTML = "Cadastre-se primeiro!";
    return;
  }

  if(loginSenha.value !== user.senha){
    loginMsg.innerHTML = "Senha incorreta!";
    return;
  }

  loginMsg.innerHTML = "Login OK — redirecionando...";
  setTimeout(()=> location.href="dashboard.html", 800);
}


/* =========================
   DADOS DOS CURSOS
========================= */

const cursosFinal = {
  basico: [
    {
      titulo:"Greetings",
      texto:"Hello = Olá | Goodbye = Adeus",
      quiz:{
        p:"Como se diz 'Olá' em inglês?",
        op:["Hello","Bye","Night"],
        c:0
      }
    },
    {
      titulo:"Numbers",
      texto:"One, Two, Three",
      quiz:{
        p:"Qual é 'Two'?",
        op:["1","2","3"],
        c:1
      }
    }
  ],

  intermedio: [
    {
      titulo:"Past Tense",
      texto:"I worked yesterday",
      quiz:{
        p:"Passado de GO?",
        op:["went","goed","go"],
        c:0
      }
    }
  ],

  avancado: [
    {
      titulo:"Conditional",
      texto:"If I had studied...",
      quiz:{
        p:"Estrutura correta?",
        op:["past + would","future","present"],
        c:0
      }
    }
  ]
};


/* =========================
   CONTROLE DE AULA
========================= */

let aulaAtual = 0;
let moduloAtual = null;

function abrirModulo(mod){
  localStorage.setItem("moduloAtual", mod);
  localStorage.setItem("aulaAtual", 0);
  location.href = "aula.html";
}


/* =========================
   CARREGAR AULA
========================= */

function carregarAula(){

  moduloAtual = localStorage.getItem("moduloAtual");
  aulaAtual = parseInt(localStorage.getItem("aulaAtual") || "0");

  if(!moduloAtual || !cursosFinal[moduloAtual]) return;

  const aula = cursosFinal[moduloAtual][aulaAtual];
  if(!aula) return;

  const t = document.getElementById("tituloAula");
  const x = document.getElementById("textoAula");

  if(t) t.innerText = aula.titulo;
  if(x) x.innerText = aula.texto;

  const quiz = aula.quiz;
  const opDiv = document.getElementById("opcoesQuiz");

  if(opDiv){
    opDiv.innerHTML = "";
    quiz.op.forEach((o,i)=>{
      const b = document.createElement("button");
      b.className="btn";
      b.innerText=o;
      b.onclick = ()=> verificarResposta(i, quiz.c);
      opDiv.appendChild(b);
    });
  }

  const r = document.getElementById("resultadoQuiz");
  if(r) r.innerText = "";
}


/* =========================
   QUIZ
========================= */

function verificarResposta(sel, cor){
  const r = document.getElementById("resultadoQuiz");
  if(!r) return;
  r.innerText = sel === cor ? "✔ Correto!" : "❌ Incorreto!";
}


/* =========================
   PROGRESSO + CERTIFICADO
========================= */

function proximaPergunta(){

  moduloAtual = localStorage.getItem("moduloAtual");
  aulaAtual = parseInt(localStorage.getItem("aulaAtual") || "0") + 1;

  const total = cursosFinal[moduloAtual].length;

  if(aulaAtual >= total){

    // salvar progresso corretamente
    let progresso = JSON.parse(localStorage.getItem("progresso")) || {};
    progresso[moduloAtual] = total;
    localStorage.setItem("progresso", JSON.stringify(progresso));

    alert("Módulo concluído!");
    location.href = "certificado.html";
    return;
  }

  localStorage.setItem("aulaAtual", aulaAtual);
  carregarAula();
}


/* =========================
   CERTIFICADO — BLOQUEIO
========================= */

function verificarCertificado(){

  const btn = document.getElementById("btnImprimir");
  if(!btn) return;

  const modulo = localStorage.getItem("moduloAtual");
  const progresso = JSON.parse(localStorage.getItem("progresso")) || {};

  if(!modulo || !cursosFinal[modulo]){
    btn.disabled = true;
    return;
  }

  const total = cursosFinal[modulo].length;

  if(progresso[modulo] >= total){
    btn.disabled = false;
    btn.onclick = ()=> window.print();
  } else {
    btn.disabled = true;
    btn.innerText = "Complete o módulo para imprimir";
  }
}


/* =========================
   PESQUISA
========================= */

function pesquisar(){

  const campo = document.getElementById("pesquisa");
  const out = document.getElementById("resultadoPesquisa");
  if(!campo || !out) return;

  const termo = campo.value.toLowerCase();
  let html = "";

  Object.values(cursosFinal).flat().forEach(a=>{
    if(a.titulo.toLowerCase().includes(termo)){
      html += `<div class="card">${a.titulo}</div>`;
    }
  });

  out.innerHTML = html || "Nada encontrado";
}


/* =========================
   AUTO LOAD AULA / CERT
========================= */

document.addEventListener("DOMContentLoaded", ()=>{
  if(document.getElementById("tituloAula")) carregarAula();
  if(document.getElementById("btnImprimir")) verificarCertificado();
});
/* =========================
IMAGENS SOBRE / INSTITUCIONAL
========================= */

const instImgs = [
 "media/sobre1.jpg",
 "media/sobre2.jpg",
 "media/sobre3.jpg"
];

let instI = 0;

setInterval(()=>{
 const el = document.getElementById("imgInst");
 if(!el) return;

 el.classList.add("fade");

 setTimeout(()=>{
   instI = (instI+1)%instImgs.length;
   el.src = instImgs[instI];
   el.classList.remove("fade");
 },400);

},5000);


/* =========================
ANÚNCIOS
========================= */

const ads = [
 "imagens/im6.jpg",
 "imagens/Im4.jpg",
 "imagens/Im5.jpg"
];

let adI = 0;

setInterval(()=>{
 const el = document.getElementById("imgAds");
 if(!el) return;

 el.classList.add("fade");

 setTimeout(()=>{
   adI = (adI+1)%ads.length;
   el.src = ads[adI];
   el.classList.remove("fade");
 },400);

},5000);



/* =========================
ANÚNCIOS SOBRE 
========================= */

const anuncios = [
  {en:"Learn English anytime, anywhere!", pt:"Aprenda inglês a qualquer hora, em qualquer lugar!"},
  {en:"Interactive lessons for all levels.", pt:"Aulas interativas para todos os níveis."},
  {en:"Become fluent faster with our method.", pt:"Torne-se fluente mais rápido com nosso método."},
  {en:"Certified courses for your career growth.", pt:"Cursos certificados para o crescimento da sua carreira."},
  {en:"Join thousands of successful students.", pt:"Junte-se a milhares de alunos de sucesso."},
  {en:"Flexible schedule to fit your lifestyle.", pt:"Horários flexíveis que se adaptam ao seu estilo de vida."},
  {en:"Learn from experienced native teachers.", pt:"Aprenda com professores nativos experientes."},
  {en:"Boost your confidence in speaking English.", pt:"Aumente sua confiança ao falar inglês."},
  {en:"Fun exercises and interactive quizzes every day.", pt:"Exercícios divertidos e quizzes interativos todos os dias."},
  {en:"Start your journey to fluency today!", pt:"Comece sua jornada rumo à fluência hoje!"}
];

let iAnuncio = 0;

function trocarAnuncio(){
  const en = document.getElementById("anuncioText");
  const pt = document.getElementById("anuncioTextPt");

  en.classList.add("fadeText");
  pt.classList.add("fadeText");

  setTimeout(()=>{
    iAnuncio = (iAnuncio + 1) % anuncios.length;
    en.innerText = anuncios[iAnuncio].en;
    pt.innerText = anuncios[iAnuncio].pt;
    en.classList.remove("fadeText");
    pt.classList.remove("fadeText");
  }, 400);
}

// inicial
document.getElementById("anuncioText").innerText = anuncios[0].en;
document.getElementById("anuncioTextPt").innerText = anuncios[0].pt;

setInterval(trocarAnuncio, 5000);